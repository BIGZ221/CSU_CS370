#include <stdio.h>
#include <stdlib.h>

double get_running_ratio();
