Scheduler.py
    contains all 3 algorithms
    imports copy to use the deep copy feature to prevent manipulating the wrong data
    imports csv to read in the csv file as a dictionary
    imports sys to get arguments from command line

QUESTIONS:
    1. Shortest Job Next
    2.
        1. Ready
        2. Waiting
        3. New
        4. Running
        5. Terminated
    3. Burst time
    4. The convoy
    5. Priority is raised if a process spends too long in a lower priority queue.